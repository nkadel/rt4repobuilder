package Mojo::LoaderTest::B;

use Mojo::Base -base;

1;
