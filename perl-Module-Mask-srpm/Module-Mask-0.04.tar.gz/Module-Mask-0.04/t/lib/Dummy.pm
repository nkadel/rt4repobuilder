package Dummy;

$Dummy::VERSION = 1;

