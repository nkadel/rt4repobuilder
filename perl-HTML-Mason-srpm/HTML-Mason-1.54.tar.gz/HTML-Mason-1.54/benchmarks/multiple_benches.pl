#!/usr/bin/perl

# This program accepts a list of CVS revision tags (or dates) and a
# benchmark to run.  It then checks out the versions of Mason
# indicated and uses them when running the benchmark indicated.  This
# helps facilitate tracking how Mason has changed over time on the
# benchmarks.

